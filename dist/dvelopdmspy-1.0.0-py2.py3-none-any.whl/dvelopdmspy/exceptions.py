class DvelopDMSPyException(Exception):
    pass
